const initialState = {
  tasks: [
    {
      id: "001",
      name: "Default Task",
      desc: "Default Description",
      status: false,
    },
  ],
};

const tasksReducer = (state = initialState, action) => {
  switch (action.type) {
    case "ADD_TASK":
      return {
        ...state,
        tasks: [...state.tasks, { ...action.payload }],
      };
    case "EDIT_TASK":
      let arr = state.tasks.map((elem) => {
        if (elem.id === action.payload.isEditItem) {
          return {
            ...elem,
            name: action.payload.name,
            desc: action.payload.desc,
            status: action.payload.status,
          };
        }
        return elem;
      });
      return {
        ...state,
        tasks: arr,
      };

    case "DELETE_TASK":
      return {
        ...state,
        tasks: state.tasks.filter((task) => task.id !== action.payload.id),
      };

    case "TOGGLE_TASK_STATUS":
      return {
        ...state,
        tasks: state.tasks.map((task) => {
          if (task.id !== action.payload.id) {
            return task;
          }
          return { ...task, isCompleted: !task.isCompleted };
        }),
      };

    default:
      return state;
  }
};

export default tasksReducer;
